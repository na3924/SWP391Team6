package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import model.Document;

public class DocumentDAO {
    private DBContext dbContext;

    public DocumentDAO() {
        dbContext = DBContext.getInstance();
    }

    public ArrayList<Document> getDocumentsByUserID(int userID) {
        ArrayList<Document> documents = new ArrayList<>();
        String sql = "SELECT d.* FROM Document d " +
                     "JOIN TutoringRegistration tr ON d.ClassID = tr.TutoringClassID " +
                     "WHERE tr.UserID = ?";
        try (Connection conn = dbContext.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, userID);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                Document doc = new Document(
                    rs.getInt("DocumentID"),
                    rs.getString("Title"),
                    rs.getString("Description"),
                    rs.getString("FilePath"),
                    rs.getString("ExternalLink"),
                    rs.getInt("UploadedBy"),
                    rs.getString("UploadDate"),
                    rs.getInt("ClassID")
                );
                documents.add(doc);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return documents;
    }
}