package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import model.Grade;

public class GradeDAO {
    private DBContext dbContext;

    public GradeDAO() {
        dbContext = DBContext.getInstance();
    }

    public ArrayList<Grade> getGradesByUserID(int userID) {
        ArrayList<Grade> grades = new ArrayList<>();
        String sql = "SELECT * FROM Grade WHERE UserID = ?";
        try (Connection conn = dbContext.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, userID);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                Grade grade = new Grade(
                    rs.getInt("GradeID"),
                    rs.getInt("TutoringClassID"),
                    rs.getInt("UserID"),
                    rs.getFloat("Score"),
                    rs.getString("AssessmentDate"),
                    rs.getString("Note")
                );
                grades.add(grade);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return grades;
    }
}